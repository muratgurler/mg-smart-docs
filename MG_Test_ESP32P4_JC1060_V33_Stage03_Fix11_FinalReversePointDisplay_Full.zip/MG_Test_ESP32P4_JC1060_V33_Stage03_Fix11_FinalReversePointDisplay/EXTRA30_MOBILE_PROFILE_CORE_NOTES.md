# Extra30 — Mobile Profile Import Core

## Architecture decision

Document digitization is no longer executed on the ESP32-P4. Camera/photo/PDF interpretation belongs to the Android/iOS companion application (or a dedicated Android device shipped with the tester). The P4 receives a prepared electrical profile and remains responsible for validating it before test use.

## Removed from the P4 project

- Embedded document-recognition backend and geometry pipeline.
- Semantic/image trace analysis and evidence review screen.
- AI model runtime/component dependencies.
- Generated-model pre-build bridge and prerequisite checkers.
- Isolated recognition build targets and their historical regression tests.
- Image/PDF upload types from the P4 transfer portal.

## Retained and simplified

- Existing temporary Wi-Fi AP/captive portal infrastructure.
- One prepared `.json` MG profile per session, maximum 256 KiB.
- Size + CRC32 file verification.
- Canonical MG JSON parser.
- `ProductionProfileContract` electrical validation.
- X1/A and X2/B connector/profile representation.
- 1:1, 1:N, N:1 and common-net topology through connected-component `nets` arrays.
- PE point 0 and dS point 63 behavior.
- Operator map review/edit before applying the profile.
- Existing test, report, Wi-Fi/Ethernet and seven-language UI infrastructure.

## Companion-app API prepared on P4

```text
GET  /api/profile/session
POST /api/profile/upload?token=<token>
POST /api/profile/chunk?token=<token>&id=<id>&part=<n>&parts=<count>&name=<name>&size=<bytes>
```

`GET /api/profile/session` returns the temporary session token, API version, format ID and maximum accepted bytes.

## Build target

```text
jc1060p4-core
```

The project should be extracted into a **new directory**, not copied over the former build directory. That avoids stale `.pio`, `managed_components` and per-environment sdkconfig files from the retired branch.
