# Stage03 Fix2 — dotted production PR compatibility

## Symptom
BLE transport, CRC and flash commit succeeded, but device-side electrical validation rejected the transferred profile with:

`Electrical profile validation failed: invalid production PR`

The transferred production identifier was `PR1100054053.015`.

## Root cause
The mobile app intentionally recognizes workplace PR values with an optional dotted suffix, while `ProductionProfileContract::validPr()` on the MG Smart Tester accepted alphanumeric characters plus `-`, `_` and `/`, but not `.`.

This was a cross-platform contract mismatch rather than a BLE failure.

## Fix
- Preserve the exact transferred PR.
- Permit `.` in the device-side production PR validator.
- Keep the `PR` prefix requirement and all other profile-validation gates unchanged.
- Add a host regression case for `PR1100054053.015`.

The BLE chain remains fail-closed: START/ACK -> CRC -> JSON parse -> electrical validation -> PROFILE_READY.
