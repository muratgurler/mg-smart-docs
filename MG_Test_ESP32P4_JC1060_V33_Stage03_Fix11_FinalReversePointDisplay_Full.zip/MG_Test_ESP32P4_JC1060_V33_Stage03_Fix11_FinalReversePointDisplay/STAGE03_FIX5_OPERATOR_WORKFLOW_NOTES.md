# Stage03 Fix5 — Operator Workflow Simplification

Date: 2026-09-19

## Goal

Reduce the successful phone -> MG Smart Tester profile flow from several engineering-oriented screens to one operator-friendly summary without weakening any validation gate.

## Normal successful flow

1. Operator opens **TELEFONDAN PROFİL AKTAR**.
2. Phone sends the already reviewed profile by BLE.
3. BLE still requires the full transport contract: START/READY, per-chunk ACK, size/CRC, prepared-profile parsing, electrical validation and terminal PROFILE_READY.
4. Only after `MgBleProfileServer::profileReady()` is true does the tester automatically open **ALINAN PROFİL**.
5. That single scrollable screen automatically performs the stored-profile validation/import and shows plain-language information:
   - production number,
   - profile ID,
   - X1 -> A / X2 -> B assignment,
   - signal pin count,
   - PE and dS state,
   - connection-definition count,
   - complete connection list (including NC and same-side/common-net pairs when present).
6. **HARİTA (İSTEĞE BAĞLI)** remains available for exceptional manual inspection/editing. It is not part of the normal mandatory path.
7. **TESTE HAZIRLA** is the single final operator action. It stays disabled unless the imported electrical profile is valid.

## Removed from normal operator flow

The following engineering terminology/screens are no longer required in the successful normal path:

- separate file/CRC review screen,
- Manifest state,
- BLE session identifier,
- raw profile filename/type/size,
- JSON wording,
- separate `PROFİLİ OKU / READ PROFILE` confirmation,
- separate `ELEKTRİKSEL DOĞRULA` confirmation.

Those mechanisms are still retained internally where needed for diagnostics and fail-closed validation.

## Failure behavior

Validation failures remain fail-closed. The operator sees a short, actionable explanation (for example production number could not be verified or received profile could not be verified), while detailed protocol/parser diagnostics remain in Serial logs.

## Wi-Fi fallback

Wi-Fi/QR remains a fallback. BLE success auto-opens the summary only after terminal PROFILE_READY. A Wi-Fi-imported stored profile can still be opened manually with **PROFİLİ KONTROL ET**.

## Safety invariants preserved

- No profile is applied unless `profileReady_` is true.
- `TESTE HAZIRLA` is disabled on validation failure.
- BLE terminal PROFILE_READY is not bypassed for automatic BLE navigation.
- Canonical profile parser and `ProductionProfileContract::buildRuntimeProfile` remain authoritative.
- Physical GPIO/backbone enablement is unchanged and remains outside this fix.
- Optional operator map edits remain separate from final profile application.

## Regression coverage

Added `host_tests/stage03_fix5_operator_workflow_contract_test.py` and wired it into `host_tests/run_tests.sh`. The test guards the direct normal flow, automatic validation, scrollable one-screen summary, plain-language wording, terminal PROFILE_READY auto-open gate, optional map review and fail-closed final action.
