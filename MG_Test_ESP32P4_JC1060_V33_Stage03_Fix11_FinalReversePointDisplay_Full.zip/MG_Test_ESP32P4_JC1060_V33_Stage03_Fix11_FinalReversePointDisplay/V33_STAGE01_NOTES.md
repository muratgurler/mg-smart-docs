# MG Smart Test V3.3 Stage01

Base: MG_Test_ESP32P4_JC1060_Fix35_Full + Hotfix7 ASCII keyboard.

## Added
- Main menu: V3.3 ADVANCED ANALYSIS entry.
- AdvancedAnalysisScreen dashboard.
- V33HardwareManager safe hardware-abstraction layer.
- V33BoardConfig centralizes V3.3 counts and future carrier-board pin mapping.
- Full Automatic BOM counts reflected in code:
  - MCP23017 x8
  - ADG725 x8
  - ADG904 x21
  - ADG732 x8
  - TMUX1219 x4
- Boot signature: V33_STAGE01_FIX35_HOTFIX7.

## Safety decision
`V33BoardConfig.h::kHardwareEnabled` is FALSE in Stage01.
No unverified Guition expansion GPIO is driven. This is intentional.

## Next Stage
Freeze the JC1060 expansion pin map against the official Guition schematic and carrier PCB, then implement real low-level drivers in this order:
1. MCP23017 digital matrix
2. ADS1115 + ADG725 + DAC80501/INA190 Kelvin LRT
3. Flex/glitch comparator latch
4. MIKROE-4770/TDC7200 + ADG904 TDR tree
5. AD9833 + ADG732/TMUX1219 + ADS8681 Pair Integrity
