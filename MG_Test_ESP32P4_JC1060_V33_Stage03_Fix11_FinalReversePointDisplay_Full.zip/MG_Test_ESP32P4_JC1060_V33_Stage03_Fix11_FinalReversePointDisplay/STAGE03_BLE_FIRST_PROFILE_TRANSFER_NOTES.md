# MG Smart Tester — Stage03 BLE-First Mobil Profil Aktarımı

Bu sürüm, OCR/görüntü anlamayı ESP32-P4 üzerinden kaldırılmış mimariyle devam ettirir. Android/iOS uygulaması belgeyi çözümler ve doğrulanabilir `MG_PROFILE_JSON_V1` profilini üretir. MG Smart Tester Cihazı profili BLE üzerinden alır, kendi tarafında tekrar doğrular ve yalnız başarılı son kontrolden sonra `PROFILE_READY` bildirir.

## 1. Aktarım mimarisi

- Birincil aktarım: Bluetooth Low Energy (BLE).
- Yedek aktarım: mevcut Wi-Fi/AP belge-profil portalı.
- BLE aygıt adı: `MG-TEST-XXXX`.
- BLE yalnız Mobil Profil/Belge Aktarımı ekranı açıkken yeni profil kabul edecek şekilde oturum açar.
- Telefon mevcut Wi-Fi bağlantısını bırakmak zorunda değildir.
- Cihaz tarafında görüntü/OCR çalıştırılmaz.

## 2. Telefon ile ortak BLE sözleşmesi

Service UUID: `6d675000-7465-7374-6572-000000000001`

Karakteristikler:

- Device info: `...0002` READ
- Session: `...0003` READ
- Control: `...0004` WRITE
- Data: `...0005` WRITE
- Status: `...0006` READ + NOTIFY

Session cevabı:

`MG1|<session-id>|262144|180`

Başlatma:

`S|<session-id>|<json-size>|<crc32-hex>|<parts>`

Cihaz `READY|<session-id>` vermeden veri kabul edilmiş sayılmaz.

Her veri paketi iki byte little-endian parça numarası + en çok 180 byte payload içerir. Her doğru parça için `ACK|<part>` döner. Tekrar gelen eski parça yeniden yazılmaz; yalnız yeniden ACK edilir.

Bitiş:

`E|<session-id>`

Başarılı doğrulama sırası:

`RECEIVED|<bytes>` → `CRC_OK` → `VALIDATED` → `PROFILE_READY`

Hata:

`ERR|<code>|<detail>`

## 3. Cihaz tarafındaki güvenlik kapıları

`PROFILE_READY` verilmeden önce:

1. Oturum kimliği doğrulanır.
2. Boyut limiti (256 KiB) doğrulanır.
3. Parça sırası ve toplam byte sayısı doğrulanır.
4. CRC32 doğrulanır.
5. Dosya mevcut `/mgdocs/profile_NNN.json` alanına atomik olarak alınır.
6. `DocumentImportValidator` ile manifest/dosya bütünlüğü doğrulanır.
7. `CanonicalWorkplaceJsonAdapter` ile JSON okunur.
8. `ProductionProfileContract::buildRuntimeProfile` ile elektriksel profil/topoloji bağımsız olarak yeniden doğrulanır.
9. Yalnız bunların tamamı başarılıysa `PROFILE_READY` gönderilir.

Bağlantı aktarım ortasında koparsa `.partial` dosyası silinir. Elektriksel doğrulama başarısızsa yarım/yanlış profil aktif profil olarak bırakılmaz.

## 4. ESP32-P4 / ESP32-C6 BLE yapılandırması

ESP32-P4 NimBLE host görevini yürütür; JC1060 üzerindeki ESP32-C6 uzak BLE kontrolcüsü olarak ESP-Hosted üzerinden kullanılır. Stage03, eski PlatformIO çalışma klasöründe önceden üretilmiş `sdkconfig.jc1060p4-core` bulunsa bile gerekli BLE Kconfig değerlerini `tools/pio_hosted_memory_config.py` ile derleme öncesinde senkronize eder.

Pozitif ayarlar arasında `CONFIG_BT_ENABLED`, `CONFIG_BT_NIMBLE_ENABLED`, `CONFIG_ESP_HOSTED_ENABLE_BT_NIMBLE` ve `CONFIG_ESP_HOSTED_NIMBLE_HCI_VHCI` bulunur. Yerel Bluedroid ve UART NimBLE taşıması kapalı tutulur.

## 5. Operatör terminolojisi

Operatöre görünen belge/profil ekranlarında artık donanım kodu olarak `P4` kullanılmaz. Kullanıcıya görünen ad `MG Smart Tester Cihazı` / `MG Smart Tester` olarak gösterilir.

## 6. Test durumu

Stage03 değişikliklerinden sonra mevcut host regresyon paketi tamamen çalıştırıldı. Mobil profil, BLE sözleşmesi, ağ, UI, sonuç tablosu, canlı grafik, doğrudan upload ve libsodium onarım testleri geçti. BLE Stage03 sözleşme testi ayrıca telefon UUID'lerini, READY/ACK/CRC/VALIDATED/PROFILE_READY akışını, callback queue kullanımını, eski sdkconfig'e BLE ayarlarının uygulanmasını ve operatör terminolojisini denetler.

Bu çalışma ortamında PlatformIO toolchain bulunmadığından gerçek ESP32-P4 firmware derlemesi yapılmadı. Son donanım derlemesi/yüklemesi Windows geliştirme bilgisayarındaki daha önce kullanılan PlatformIO kurulumu ile yapılmalıdır.

## 7. Windows PlatformIO doğrulaması

Projeyi ayrı klasöre çıkarın; örneğin:

`C:\MG\MG_P4_STAGE03_BLE`

PowerShell:

```powershell
cd C:\MG\MG_P4_STAGE03_BLE
C:\Users\Murat\.platformio\penv\Scripts\platformio.exe run -e jc1060p4-core
C:\Users\Murat\.platformio\penv\Scripts\platformio.exe run -e jc1060p4-core -t upload
C:\Users\Murat\.platformio\penv\Scripts\platformio.exe device monitor -b 115200
```

Normalde Clean gerekli değildir. Stage03 ilk BLE derlemesinde eski `sdkconfig` nedeniyle Kconfig/CMake yeniden yapılandırması zaten tetiklenebilir. Sadece olağan dışı cache/Kconfig davranışı görülürse bir kez `-t clean` uygulanmalıdır.

Beklenen seri logları:

- `[BOOT][00B] ESP-Hosted/NimBLE profile receiver initialization`
- `[BOOT][00B] BLE profile receiver=READY`
- `[BLE-PROFILE] GATT ready ...`
- Mobil Profil ekranı açılınca: `[BLE-PROFILE] session OPEN ...`
- Aktarım başlarken: `[BLE-PROFILE] START ...`
- Son doğrulamada: `[BLE-PROFILE] PROFILE_READY ...`

## 8. İlk gerçek cihaz testi

1. Firmware'i derleyip JC1060'a yükleyin.
2. MG Smart Tester'da Mobil Profil/Belge Aktarımı ekranını açın.
3. Telefonda daha önce hazırladığımız MG Smart Tester uygulamasını açın.
4. Bilinen DB15 profilini kullanın: X1:1→X2:1 ... X1:15→X2:15 ve House→House/dS.
5. `Bluetooth ile MG Smart Tester Cihazına Gönder` seçeneğine basın.
6. Telefonun `MG-TEST-XXXX` cihazını bulduğunu doğrulayın.
7. Telefonda son durum `PROFILE_READY` olmalıdır.
8. Cihazda profil inceleme ekranına geçip 15 sinyal + dS bağlantılarını kontrol edin.
