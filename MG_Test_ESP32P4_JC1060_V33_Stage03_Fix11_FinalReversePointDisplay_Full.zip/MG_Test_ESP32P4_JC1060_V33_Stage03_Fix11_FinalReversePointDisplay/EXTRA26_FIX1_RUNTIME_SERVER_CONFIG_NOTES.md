# Extra26 Fix1 - Runtime Workplace Server Configuration

This Fix1 keeps the Extra26 workplace PR HTTP architecture but removes the need
to rebuild firmware when the real company server details become available.

## Operator path

`AYARLAR / SETTINGS -> WORKPLACE SERVER`

Values are stored in the ESP32 Preferences/NVS namespace `mg-workplace`.
Incomplete settings may be saved, but the workplace lookup remains
`CONFIG_REQUIRED` until validation succeeds. Saving never starts a test.

## Fields

1. **PR URL / PATH**
   - Full endpoint template, for example `https://server.example/api/profile/{PR}`.
   - Literal `{PR}` is mandatory and is percent-encoded at lookup time.
2. **AUTH MODE**
   - `NONE`
   - `BASIC`
   - `BEARER`
   - `HEADER` (custom header such as `X-API-Key`)
3. **USERNAME**
   - Used by BASIC authentication.
4. **PASSWORD / TOKEN / VALUE**
   - BASIC password, Bearer token, or custom-header value depending on auth mode.
   - Masked on screen and never printed to Serial.
5. **CUSTOM HEADER NAME**
   - Used only by HEADER mode.
6. **HTTPS CA PEM**
   - Required for HTTPS. Insecure TLS is never enabled.
   - Multiline editor supports PEM entry. Runtime editor limit: 3500 bytes.
7. **RESPONSE FORMAT**
   - `CANONICAL_JSON_V1`: Extra26 canonical MG JSON keys.
   - `MAPPED_JSON_V1`: same electrical connected-component structure with
     manually mapped JSON member names.
8. **JSON FIELD MAP**
   - Semicolon-separated mapping used by `MAPPED_JSON_V1`.
   - Default mapping:
     `pr=productionPr;customer=customerReference;rev=revision;profile=profileId;pins=signalPinCount;peA=includePeA;peB=includePeB;dsA=includeDrainShieldA;dsB=includeDrainShieldB;connA=connectorA;connB=connectorB;nets=nets;A=A;B=B;kind=kind;gender=gender;contacts=contacts;name=name`
9. **TIMEOUT (ms)**
   - Allowed: 500..60000.
10. **MAX RESPONSE (bytes)**
   - Allowed: 1024..131072.

## Response mapping boundary

`MAPPED_JSON_V1` supports a workplace JSON response whose semantic structure is
the same as Extra26 but whose member names differ. It maps identity fields,
connector fields and connected-component `A[]` / `B[]` net fields without a
firmware rebuild.

If the real company response later turns out to be structurally different
(for example XML/CSV, a deeply nested envelope, or a completely different net
representation), a site-specific response adapter will still be required. The
HTTP/auth/CA/NVS/UI layers in this Fix1 do not need to change.

## Security behavior

- HTTPS without a CA is rejected.
- No `setInsecure()` fallback exists.
- Custom header names reject colon/CR/LF.
- Bearer/custom-header values reject CR/LF.
- BASIC username rejects colon to avoid ambiguous credentials.
- Secrets are masked in the UI and not written to Serial logs.
- Credentials are persisted in local Preferences/NVS. They are not encrypted
  by this application layer; platform flash/NVS encryption can be enabled later
  if required by company policy.
- `SIFIRLA / SIL` clears the saved workplace configuration and returns the
  client to `CONFIG_REQUIRED`.
- Successful profile lookup still ends at READY; operator START is mandatory.

## Verification

- Existing Extra21-Extra26 regression path: PASS for the rerun groups.
- Extra25 completion report contract: 24/24 PASS.
- Extra26 workplace HTTP contract: 17/17 PASS.
- Extra26 Fix1 runtime server configuration: 25/25 PASS.
- New C++ config/mapped-response executable test: PASS.
- New LVGL settings/config store syntax test: PASS with host stubs.
- WorkplaceProfileHttpClient auth/TLS syntax test: PASS with host stubs.
- Real `pio run -e jc1060p4` was not available in this environment and must be
  confirmed on the JC1060 PlatformIO workstation.
