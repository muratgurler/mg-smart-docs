# Stage03 Fix3 - Graph Pin Labels + ASCII-Safe Arrows

## Field symptom
On the imported SIMPLE_SUBD profile graph, all 16 straight-through lines were drawn, but only pin label `1` was visible on each side on the first frame. The editor/profile graph used the same P4 double-buffered full-refresh renderer as the result graph, but the deferred two-frame label refresh was enabled only for `resultMode_`.

## Fix
- `MapGraphScreen::presentPreparedScreen()` now schedules two post-present refresh passes for **all** graph modes, including imported/editor profile maps.
- Every visible A/B pin label is refreshed and invalidated on both native framebuffers, so `1..15` plus `dS` are present without touching another button.
- Existing mapping data and line geometry are unchanged. This is display-only.
- Unsupported Unicode arrow glyphs in firmware operator-visible source strings were replaced with ASCII-safe `->`, `<-`, and `<->` forms to avoid square/missing-glyph boxes with the current compact fonts.

## Regression
- Existing Extra31 graph contract updated to require two-buffer refresh for every graph mode.
- Added `stage03_fix3_graph_labels_ascii_arrow_contract_test.py`.
