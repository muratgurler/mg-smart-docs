#pragma once
// Fix32 compatibility wrapper for projects updated in-place from Fix31.
// New code should include MgNetworkManager.h directly.
#include "MgNetworkManager.h"
