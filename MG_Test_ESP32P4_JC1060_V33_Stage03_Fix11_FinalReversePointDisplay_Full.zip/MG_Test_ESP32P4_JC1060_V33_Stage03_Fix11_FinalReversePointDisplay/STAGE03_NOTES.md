# Stage03 dogrulama notlari

## Fix12

- Ana menude Normal ve Sub-D tarama ayri etkin seceneklerdir.
- Sub-D profil dongusu `25, 9, 15, 37, 44, 50, 62` sirasindadir ve varsayilan
  Sub-D25'tir.
- Sub-D profilinde PE bulunmaz; aktif noktalar `1..N + dS` olarak olusur.
- Normal modda pin sayisi 1..62 arasinda `-` ve `+` ile degisir; PE ve dS
  birbirinden bagimsiz acilip kapatilabilir.
- Dil ekraninda yedi dilin bayragi kodla cizilir. Turkce ve Avrupa dillerinin
  aksanli karakterleri uc sikistirilmis DejaVu Sans alt-kumesine eklendi;
  gereksiz Montserrat 10/14/20 fontlari kapatildi.
- Ana menu, dil, tarama ve dokunmatik test ekranlarinda ortak ses dugmesi
  vardir. Sessiz durumda hoparlorun uzerinde kirmizi capraz cizgi gorunur.
- Host dogrulamasi 12 tarama regresyon grubunu, 7 dil tablosunu, profil
  sirasini, Sub-D PE yasagini, normal mod kontrollerini, fontlari, bayraklari
  ve ses ikonunu denetler.

## Fix11

- Tarama ekranina kalici `NON-STOP` dugmesi eklendi.
- NON-STOP acikken A->B ve B->A bittikten sonra durum `Complete` olmaz;
  rapor tamponlari temizlenir ve yeni dongu A->B/PE noktasindan otomatik
  baslar.
- Bu mod toplu kablo kontrolu icindir: ara donguler icin CSV/toplu rapor
  yazdirilmaz ve `HATADA DUR` kapali tutulur.
- NON-STOP mevcut dongu icinde kapatilirsa tarama konumunu kaybetmez; donguyu
  tamamlar, normal sekilde durur ve son dongunun raporunu verir.
- Seri monitorde `C` tusu NON-STOP modunu acip kapatir.
- Host regresyonu kesintisiz donguyu, rapor tamponunun her dongude
  yenilenmesini ve normal moda guvenli donusu denetler.
- Hizli yama paketi; `ScanSession`, `FrontPanelController`,
  `TouchControlPanel`, `P4Localization` ve ana `.ino` olmak uzere dokuz
  firmware dosyasini icerir.

## Fix10

- Fiziksel kartta farkli gorunen LVGL poligon doldurucusu ok ciziminden
  cikarildi.
- Onizlemedeki yedi koordinat `DirectionArrow.cpp` icinde degistirilmeden
  korunur ve canvas tamponuna satir satir dogrudan yazilir.
- Ok basi, iki omuz, iki kuyruk kosesi ve iki egimli baslangic kosesi cihazda
  da keskin kalir.
- Firmware icin degisen tek dosya `DirectionArrow.cpp` dosyasidir.

## Fix09

- `ScanScreen::update()` UI yenilemesi yapip yapmadigini bildirir. Ana dongu,
  `Running` disina cikilan ayni turda hizli dugmeleri yeniler; tam dongu,
  manuel duraklatma ve hatada durma sonrasinda `DURAKLAT` yazisi kalmaz.
- `TEK ADIM` tarama ekraninin ust cubuguna tasindi ve Kontroller penceresinden
  kaldirildi. Boylece duraklatilan tarama penceresinden ayrilmadan ilerletilir.
- Konnektor panellerindeki A ERKEK/B DISI basliklari kaldirildi. Sub-D govdesi,
  montaj kulaklari, vidalar ve cinsiyete gore kontaklar bitmap kullanmadan
  PSRAM canvas uzerinde cizilir.
- Yon oku ayri yuvarlak dikdortgen ve uc yerine tek yedi koseli poligondur;
  bas, omuz ve kuyruk koselerinin tamami keskindir.
- Host donanim sozlesmesi; yeni hizli dugme sayisini, Tek Adim'in overlay'e
  geri donmemesini, buton yenileme yolunu, Sub-D cizimini ve keskin oku denetler.

## Fix08

- Tam A->B/B->A dongusu bitince yon A->B baslangicina doner.
- Buyuk merkez oku dokunmatik yon dugmesine cevrildi; ustteki kucuk yon
  dugmesi kaldirildi.
- Yon degisimi S3 davranisiyla eslesti: son gorunen karsi kontak yeni kaynak
  olur ve tarama ayni noktadan terse devam eder.
- A12->B12 senaryosu B12, B11, B10; yanlis A8->B9 senaryosu B9, B8...
  olarak host regresyonlariyla dogrulandi.
- Ok 236x92 alana buyutuldu ve kuyrugu kisaltildi.
- LED bar araligi 1 piksele indirildi; DB25 etiket fontu 20 piksele buyutuldu,
  A/numara/B dikey araliklari sikilastirildi.

## Fix07

- S3 ana menu sirasi P4'e aktarildi; cihaz artik otomatik tarama ekraninda
  baslamaz.
- Demo Birebir Test ve GT911 Diagnostik etkindir. Olcum karti, SD profili veya
  QR okuyucu gerektiren secenekler bilerek pasiftir.
- Birebir tarama ekrani `Idle/HAZIR` durumunda acilir.
- MENU, BASLAT/DURAKLAT, YON, HATADA DUR ve KONTROLLER hizli dugmeleri tarama
  ekraninda kalicidir.
- Yedi dil secimi ve NVS kaliciligi eklendi.

## Fix06

- Fix06'da firmware dogrudan tarama ekraninda basliyordu; Fix07 bu gecici
  davranisi kaldirip S3 uyumlu ana menu acilisina cevirdi.
- `KONTROLLER` sanal on paneli S3 cihazindaki 11 kontrol islevini dokunmatik
  dugmelerle sunar; LED bar alani kalici olarak daraltilmaz.
- Bes noktali test `DIAGNOSTIK > DOKUNMATIK TESTI` altina tasindi.
- Tarama ve dokunmatik test ekranlari ayri LVGL kok ekranlaridir; test ekrani
  yeniden kullanilir ve her geciste yeni ekran ayirma islemi yapilmaz.
- LED sonucu birikimli degildir. Yalnizca o an surulen taraf pini ile bulunan
  karsi kontak yanar; rapor sonuclari ayri bellekte korunur.
- A->B sirasi `PE -> 1..maksimum -> dS`, B->A sirasi
  `dS -> maksimum..1 -> PE` olarak host testiyle dogrulanir.
- Yanlis baglanti orneginde ayni numarali iki bar yerine gercek cift, ornegin
  `A8 -> B9`, renklenir.

## Fix05

- Acilisa bes noktali GT911 dogrulama ekrani eklendi.
- Tum ekran dokunus yakaladigi icin eksen/ayna hatasinda bile gercek koordinat
  kaydi alinir; her hedef icin beklenen/okunan deger ve tolerans sonucu yazilir.
- Test bitince dokunmatik dugmeyle tarama arayuzune gecilir.
- Dokunmatik olay uretmiyorsa seri monitordeki `K` komutu testi atlar.

## Fix04

- Donanim seri kaydi, JD9165 panelinin basladigini ve yeniden baslatmanin
  GT911 ilk I2C okumasindan sonra `ESP_ERROR_CHECK` ile olustugunu kanitladi.
- Ureticinin JC1060 Arduino/ESP-IDF orneklerine uygun olarak GT911 reset ve
  interrupt pinleri `GPIO_NUM_NC` (`-1`) yapildi; I2C GPIO7/GPIO8 korunur.
- GT911 baslatma sonucu artik kontrol edilir. Dokunmatik yoksa firmware abort
  olmaz; LVGL giris surucusunu atlayip ekran ve seri kontrollerle devam eder.
- Dokunmatik okuma ve dondurme fonksiyonlarina gecersiz handle korumasi eklendi.

## Fix03

- `esp_lcd_dpi_panel_config_t` artik alan sirali C++ tasarimiyla kurulmaz.
- Yapilandirma sifirlanir ve tum DPI alanlari normal atamalarla doldurulur.
- ESP-IDF yapisindaki alan sirasi degisse bile bu kaynak derlenebilir.

## Fix02

- JD9165 DPI makrosundaki gecersiz `.flags.use_dma2d` ic ice tasarimi,
  C++17 uyumlu `.flags = {.use_dma2d = true,}` yapisina cevrildi.
- Donanim sozlesmesi testi eski bicimin geri gelmesini engeller.

## Fix01

- `P4LvglPort.h` dosyasina eksik `esp_lcd_mipi_dsi.h` basligi eklendi.
- DPI aktarim tamamlanma callback'i korunarak LVGL tamponunun erken serbest
  birakilmasi engellendi.
- Host donanim sozlesmesi testi gerekli basligi ve callback kaydini denetler.

## Donanim eslesmesi

- Arka kart etiketi ile hedef `JC1060P470C_I` olarak dogrulandi.
- Dokunmatik seri koordinatlari yaklasik 0..1023 ve 0..599 araligini gostermis,
  1024x600 panel tespitini desteklemistir.
- Uretici deposundaki JD9165BA dtsi zamanlamasi koda aktarildi.
- Eski ST7701 kaynaklari bu hedeften kaldirildi.

## Yazilim kontrolleri

- S3 ve JC4880 kaynaklari degistirilmedi; yeni hedef ayri klasordedir.
- PE indeks 0, dS indeks 63 sozlesmesi korunur.
- A ve B sabit konumdadir; B->A taramasinda yalnizca ok yonu degisir.
- Profil kadar LED bar olusturulur; bos kanal gosterilmez.
- Sub-D25: 25 + dS = 26 nokta; PE yoktur.
- Normal 25: PE ve dS aciksa PE + 25 + dS = 27 nokta.
- Host regresyonlari profil, iki yon, rapor ve durum makinesini denetler.

## Donanimda ilk kontrol

Ilk yuklemeden sonra su sirayla bakilmalidir:

1. Seri monitorde `JD9165 1024x600 panel ready` gorunmeli.
2. Arka isik sabit acik kalmali.
3. Tarama arayuzu 1024x600 alani doldurmali.
4. Dokunmatik koordinatlari yatay yonle ayni olmali.
5. DB25 ekraninda 27 A ve 27 B bari gorunmeli.

Gercek karta yukleme yapilmadan panelin fiziksel goruntu verdigi iddia edilmez;
bu paket dogru uretici surucusu ve kart pinleriyle hedef derleme icin hazirdir.

## Stage02 Extra17 - Digital Core Backbone Batch3

The role-aware feature UI is now backed by a hardware-agnostic digital workflow core for
128-node sweep, Cable Learn, Smart Probe, Self Test/Calibration and adjacent-only
Multi-Connector tests. DemoScanSource resolves real CableNetGraph connected components;
learning/probe therefore preserve same-side and one-to-many/N:N nets. Legacy scan faults
remain available as an optional overlay, while learning and segment demos can disable it.
Full normal scan contract remains 64 A + 64 B and sender LOW with all remaining 127 nodes
observed. Hardware outputs remain disabled until the carrier PCB driver is attached.

### Stage02 Extra18 QualityCoreBatch4
Added a shared quality-domain demo core for Kelvin, PE/dS, Fixture Health/SPC and
SHT40/Environment. The new core is LVGL-independent and hardware-independent so the
same UI/controller layer can later attach production drivers after PCB validation.

### Extra19 - HighSpeedCoreBatch5
- Added `HighSpeedBackboneCore` for TDR, Pair Integrity, USB-C E-Marker/PD Cable Identity, and Flex/Glitch.
- TDR demo now owns selected A node, VOP/timing/distance/fault/confidence data.
- Pair demo now owns 20/50/100/250 kHz amplitude/phase/crosstalk/split-pair results.
- USB-C demo separates Discover Identity from explicit profile comparison and never models a high-power load.
- Flex/Glitch demo models a hardware latch and preserves recorded events when the latch is cleared.
- `BackboneDemoScreen` consumes these module-owned snapshots; real PCB outputs stay disabled.
- Full host regression suite passed; target PlatformIO compile was not available in this environment.

### Extra22 ResultArchiveBatch8
Unified workflow now has RAM demo result history, report-row formatting, recent-profile cache, RETEST and safe NEXT CABLE behavior. Production PR identity is cleared before a new PR-driven cable can proceed. Cached-profile restore is explicit and never auto-starts.

### Extra23 PersistenceReportBatch9
- Result/profile archive now survives reboot through a CRC32 + schema-versioned LittleFS blob.
- Storage paths: `/mgdata/workflow_archive.bin`, temp/backup replacement files under `/mgdata`.
- Report exports: `/mgreports/results_all.csv` and `/mgreports/result_selected.csv`.
- Archive summary includes PASS/WARNING/FAIL, retest count and first-attempt FPY for the current 32-record window.
- NEXT CABLE touch/physical seam is workflow-aware; it is no longer a bare scan reset.
- Scan-screen NEXT CABLE is enabled only after workflow COMPLETE.
- PR/customer-driven next cable requires a new identifier; old PR is never silently reused.
- RETEST and NEXT CABLE remain READY-only transitions; START is still an operator action.
- This batch does not enable any carrier-PCB output and does not change the GPIO Pin Freeze Candidate.

## Extra24 / ProductionIdentityBatch10

- Added `ProductionProfileContract`: strict dual-identifier/revision/profile and
  64-point topology validation for future real PR/customer server responses.
- Added `ProductionWorkflowBridge`: validated record -> `CableProfile` /
  `CableMap` -> unified workflow READY, always with operator START required.
- `TestWorkflowController` now preserves the initiating network source via
  `acceptNetworkResolvedProfileForSource()` while retaining the older wrapper.
- Existing Network demo now travels through the same contract, preventing a
  weaker duplicate PR -> READY path.
- Full host regression PASS; Extra24 contract 17/17 PASS; main-menu language
  touch guard retained.
- Real workplace HTTP URL/response adapter remains the next batch and must use
  actual company API details rather than guessed field names/endpoints.
