#pragma once
class NetworkClient {};
