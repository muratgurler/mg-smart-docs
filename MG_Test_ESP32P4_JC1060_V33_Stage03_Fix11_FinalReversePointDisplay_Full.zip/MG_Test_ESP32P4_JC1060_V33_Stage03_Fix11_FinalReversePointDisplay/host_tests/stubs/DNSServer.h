#pragma once
class DNSServer {};
