# EXTRA31 Fix3 — Result Graph Double-Buffer Pin Labels

## Field symptom
On first entry to **GRAFİKLE GÖSTER / BİRLİKTE**, connection lines were present but only pin label `1` was visible. After cycling EXPECTED / MEASURED / COMBINED, all pin numbers appeared. Fix2 build-order changes did not alter the field symptom.

## Root cause addressed
JC1060/P4 display port runs LVGL `full_refresh` on two native MIPI-DPI framebuffers. The first screen presentation could swap a frame before the complete newly-created pin-label layer had become coherent in both native buffers. Later view-button presses forced extra full refresh/swap cycles, which made the labels appear.

## Fix
- Result graph schedules **two post-present refresh passes**.
- Main MapGraph loop services one pass per LVGL cycle.
- Each pass re-runs result label refresh, forces layout, explicitly invalidates every visible A/B label, and invalidates the complete screen.
- Two passes ensure both native framebuffers receive the same complete label layer.
- Editor graph behavior is unchanged.
- Filters remain visible only when active test points are >30.

## Build / upload
Firmware source changed: run **Build**. No Clean is required. After a successful build use `UPLOAD_EXISTING_FIRMWARE.bat`.
