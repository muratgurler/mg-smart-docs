# MG Smart Tester V3.3 — Extra27 Analysis Report Batch13

## Amaç
KABLO ANALIZI menüsünden başlatılan ölçümlere Normal Test raporuyla aynı kullanım modelini ekler: sabit başlık, dikey kaydırılabilir tablo, doğal satır sırası ve durum renkleri.

## Raporlanan analizler
- TAM KABLO TESTI / Scan128: A->B 0..63 sonra B->A 0..63 doğal sıra; beklenen, bulunan, R(mOhm), sonuç.
- BAGLANTI HATALARI: mevcut Normal Test / CompletionReportScreen yolunu kullanır; ikinci bir rapor sistemi oluşturulmaz.
- DIRENC OLCUMU / KRIMP-TEMAS: Kelvin sonucu R, referans, Delta-R ve verdict tablosu.
- KOPUK YERINI BUL / TDR: hat, arıza tipi, yaklaşık mesafe, güven/kalibrasyon ve sonuç.
- BUKUMLU CIFT KONTROLU: çift/frekans, genlik, faz, crosstalk, split-pair/verdict.
- KALIBRASYON / SELF TEST: kontrol maddeleri doğal plan sırasıyla PASS/WARNING/FAIL.
- ANLIK TEMASSIZLIK: sürekli izleme olduğu için otomatik rapor açılmaz; SONUC veya OLAY LISTESI ile canlı snapshot tablosu açılır.

## Renkler
Normal Test / ScanScreen paleti korunur:
- PASS/OK: 0x35D273 yeşil
- OPEN: 0xE9EEF2 beyaz
- SHORT/WARNING: 0xFFD34D sarı
- WRONG/FAIL: 0xF04444 kırmızı
- HIGH-R: 0xFF922E turuncu

## Önemli düzeltme
DigitalSweepRunner içinde tam kablo taramasında cursor iki kez artırılabiliyordu. Bu, bazı pinlerin atlanmasına yol açabilecek eski bir hataydı. Extra27 ile tek artışa düzeltildi ve 128 doğal satır sırası host regresyonuyla kilitlendi.

## UI davranışı
Rapor alt butonları:
- OLCUME DON: aynı ölçüm ekranına döner.
- KABLO ANALIZI: analiz menüsüne döner.
- ANA MENU: ana menüye döner.

## Demo / gerçek donanım notu
Mevcut Kelvin demo engine tek seçili-hat ölçümü üretir; bu nedenle demo raporu tek satırdır. Gerçek ADS122C04/Kelvin driver her hattı ayrı ölçtüğünde aynı tablo veri modeli satır başına gerçek ölçümü gösterecek şekilde hazırlanmıştır.

## Testler
- Analysis Report Batch13 data test: PASS
- Analysis Report Batch13 contract: 21/21 PASS
- Extra25 Completion Report contract: 24/24 PASS
- Main menu 72 px / PRESS_LOCK language touch regression: PASS
- AnalysisReportScreen + BackboneDemoScreen + core C++ host syntax (-Wall -Wextra -Werror -pedantic): PASS
