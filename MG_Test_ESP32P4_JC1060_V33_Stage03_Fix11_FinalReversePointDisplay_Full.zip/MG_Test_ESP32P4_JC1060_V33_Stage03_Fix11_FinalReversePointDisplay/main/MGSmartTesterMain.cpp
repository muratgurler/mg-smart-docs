#include <Arduino.h>
#include "../MG_Test_ESP32P4_JC1060_Stage03.ino"
