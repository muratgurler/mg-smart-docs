# MG Smart Tester EXTRA31 Fix1 - Upload Reliability

## Purpose
Prevent a successful ESP32-P4 build from being blocked during the later Upload step by ESP-IDF Component Manager / `managed_components` Windows file locks.

## Root cause observed on the JC1060 development PC
1. EXTRA31 PlatformIO Build completed successfully.
2. PlatformIO Upload entered CMake / Component Manager again even though `firmware.bin` already existed.
3. Windows returned `WinError 32` while Component Manager tried to replace `managed_components/espressif__libsodium/libsodium`.
4. The interrupted replacement left the component tree incomplete.
5. The next Upload failed because `aead_chacha20poly1305.c` was missing.
6. Direct `esptool` flashing of the already-built binaries succeeded.

This was not an EXTRA31 application-code or ESP32-P4 serial-link failure.

## Added direct upload path
- `UPLOAD_EXISTING_FIRMWARE.bat`
- `tools/upload_existing_firmware.py`

The direct uploader **does not call `platformio.exe`**. Therefore it does not start SCons, CMake or ESP-IDF Component Manager.

Default files:
- `.pio/build/jc1060p4-core/bootloader.bin`
- `.pio/build/jc1060p4-core/partitions.bin`
- `.pio/build/jc1060p4-core/firmware.bin`

The uploader reuses flash mode/frequency/size and addresses from the existing `flash_args` when available, but deliberately uses PlatformIO's top-level binary files instead of fragile nested CMake paths.

## Normal workflow
1. PlatformIO **Build**.
2. Confirm Build succeeded.
3. Run `UPLOAD_EXISTING_FIRMWARE.bat` instead of PlatformIO Upload.

No Clean is required by default.

## Safety checks
The direct uploader refuses to flash when:
- required `.bin` files are missing;
- source/config files are newer than `firmware.bin` (stale-build protection).

Optional command-line arguments:
- `--port COM8` : force a serial port; otherwise esptool auto-detects.
- `--app-only` : write only `firmware.bin` at the app offset.
- `--dry-run` : print the command without flashing.
- `--allow-stale` : intentionally bypass stale-build protection.

## Important
This fix does not alter firmware source, hardware behavior, partition layout, OCR architecture, scan logic or result graph behavior. It is a host-side upload reliability tool only.

## One-time repair for the already interrupted libsodium tree
The current MG30 working folder was already damaged by the interrupted Component Manager copy. Before the **next Build**, run:

- `REPAIR_LIBSODIUM_ONCE.bat`

It moves only:

`managed_components/espressif__libsodium`

to:

`.mg_component_quarantine/...`

It does **not** delete `.pio`, the full `managed_components` directory, or any source file. The next normal Build can then recreate libsodium cleanly.
