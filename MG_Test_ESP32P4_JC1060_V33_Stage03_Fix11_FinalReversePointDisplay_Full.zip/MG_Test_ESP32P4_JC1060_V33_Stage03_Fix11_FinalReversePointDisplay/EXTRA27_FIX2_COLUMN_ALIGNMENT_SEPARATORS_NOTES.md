# Extra27 Fix2 — Column Alignment & Header Separators

- Kablo Analizi sonuç tablosundaki tüm gövde hücreleri kendi sabit başlıklarının altında yatay ortalanır.
- Sabit başlık hücrelerinin sağ kenarında 2 px dikey ayraç bulunur.
- Başlık ve gövde aynı sütun genişliği tablosunu kullanmaya devam eder.
- Kaydırma, satır renkleri, doğal sonuç sırası ve ölçüm mantığı değiştirilmemiştir.
- Regresyon testi merkez hizalama ve dikey ayraç sözleşmesini kilitler.
