# MG Smart Tester — ESP32-P4 Core + Mobile Profile Import

This is the simplified ESP32-P4 firmware branch after moving document digitization to the Android/iOS companion application.

## P4 responsibilities

- JC1060 touch UI and seven-language interface.
- Normal, multi-connector and cable-learning workflows.
- Cable map editing and electrical profile validation.
- PE and drain/shield (`dS`) handling.
- Test/result/report workflows and production profile support.
- Wi-Fi/Ethernet services.
- Temporary local Wi-Fi profile-transfer session.
- Import of one prepared MG electrical profile, automatic device validation, one operator summary, then test preparation.

The P4 firmware does not decode camera images or run document-recognition AI models. The phone application converts a photo/PDF into the electrical profile before transfer.

## Build target

PlatformIO environment:

```text
jc1060p4-core
```

Framework: ESP-IDF with Arduino as a managed component.

Main managed dependencies:

- `espressif/arduino-esp32 3.3.6`
- `lvgl/lvgl 8.4.0`

The previous AI-model/runtime components and generated-model pre-build bridge are not part of this project.

## Recommended build

Open this project as a fresh directory and run **Build**, then **Upload** after a successful build. A PlatformIO Clean is not required for a freshly extracted project.

## Mobile profile transfer

The existing temporary AP/captive-portal mechanism remains available. Browser/service upload is at `/doc`.

Stable companion-app API:

```text
GET  /api/profile/session
POST /api/profile/upload?token=<session-token>
POST /api/profile/chunk?token=<session-token>&id=<transfer-id>&part=<n>&parts=<count>&name=<name>&size=<total-bytes>
```

Only one prepared profile, up to 256 KiB, is accepted per transfer session. Internally the firmware still verifies file size/CRC32, parses the canonical MG profile and validates the electrical topology. These engineering details are hidden from the normal operator UI; the operator sees one plain-language summary before preparing the test.

See `MG_MOBILE_PROFILE_JSON_V1.md` and `mobile_profile_example.json`.

## Permanent regression constraints

The reliable main-menu language selector remains a protected requirement: 72 px height at Y=504, 8 px extended click area, PRESS_LOCK, and non-clickable transparent child labels/row. The host regression test remains in `host_tests/main_menu_language_touch_contract_test.py`.

## Stage03 Fix2
Accepts workplace production PR identifiers with dotted suffixes such as `PR1100054053.015`, matching the companion app extractor while preserving all existing validation gates. See `STAGE03_FIX2_DOTTED_PR_NOTES.md`.

## Stage03 Fix3 (2026-09-19)
Imported/editor cable-map graphs now populate pin labels on both P4 framebuffers on first display (`1..N`, `dS`/PE as applicable). Operator-visible Unicode arrow glyphs that rendered as squares were replaced with ASCII-safe arrows. See `STAGE03_FIX3_GRAPH_LABELS_ASCII_ARROWS_NOTES.md`.

## Stage03 Fix5 (2026-09-19)
Normal phone-to-tester workflow is reduced to one operator-facing profile summary. After BLE reaches terminal `PROFILE_READY`, the transfer screen advances automatically to a scrollable summary that shows PR/profile, X1->A and X2->B assignment, signal count, PE/dS state and the electrical connection list. The former file/CRC review and separate `READ PROFILE` confirmation are skipped in normal operation. `MAP (OPTIONAL)` remains available for exceptional/manual inspection, while `PREPARE FOR TEST` is the single final operator action. JSON/CRC/manifest/session identifiers remain available internally for diagnostics but are not normal operator terminology. See `STAGE03_FIX5_OPERATOR_WORKFLOW_NOTES.md`.

## Stage03 Fix6 (2026-09-19)
The fast Fix5 operator flow is preserved, but the optional imported-map path is now safer and still editable when needed. `HARITAYI GOR / DUZENLE` opens the document map locked by default; an explicit `DUZENLE` action is required before connection changes are allowed. Edited maps are revalidated through `ProductionProfileContract` before they can replace the last valid draft, and `TESTE HAZIRLA` remains blocked after a rejected edit. The transfer screen also reports completed phone transfer instead of continuing to show a waiting-for-phone state after the profile arrives. See `STAGE03_FIX6_OPTIONAL_MAP_EDIT_REVALIDATION_NOTES.md`.


## Stage03 Fix7
Operator map edits preserve the original phone map, require explicit confirmation before test preparation, and can be restored. Mobile PR/profile metadata now reaches the end-of-test report, while demo/simulation results are explicitly labeled as non-physical measurements.

## Stage03 Fix8 (2026-09-19)
The phone-profile transfer screen is now truly BLE-first: the temporary Wi-Fi AP and QR are off by default and are opened only by an explicit, localized Wi-Fi fallback button. When enabled, the QR and SSID/password/address/session details appear; when disabled they are hidden. The previous dynamic Turkish-only `Wi-Fi yedek` and `[BAĞLI]` fragments are now seven-language localized, with a regression guard that prevents this transfer-screen localization leak from returning. See `STAGE03_FIX8_WIFI_ONDEMAND_LOCALIZATION_NOTES.md`.

## Stage03 Fix9 (2026-09-20)
The end-of-test report header was simplified for production operators. It now shows only the production PR, plus `DEMO/SIM` while the demo engine is active. REF, REV, PROFILE, TEST, ELECTRICAL NET MAP and ONE-TO-ONE are no longer shown on this report screen; the underlying metadata remains stored for archive/service use. See `STAGE03_FIX9_REPORT_HEADER_SIMPLIFY_NOTES.md`.

## Stage03 Fix10 (2026-09-20)
Finite-test reports now add an operator-oriented physical-fault summary for strict identity 1:1 cable maps. Bidirectional duplicates are collapsed, so the Sub-D15 demo is presented as one crossed pair `8/9` plus one open line `15`, while the detailed row table and raw electrical measurements remain unchanged. Complex/common-net maps intentionally fall back to directional statistics rather than guessing a physical count. Demo values remain explicitly non-physical and `[SIM]`. See `STAGE03_FIX10_PHYSICAL_FAULT_SUMMARY_NOTES.md`.


## Stage03 Fix11 - Final Reverse Point Display
Finite two-direction scans now keep the last B->A point (B1 -> A1) visibly on the scan screen before opening the completion report. The report transition waits for the selected scan dwell or at least 300 ms, whichever is longer.
