# Extra25 Fix2 — Scroll Table + Resistance Columns

## Scope

This fix changes the finite-test and Cable Learn completion report presentation only.
NON-STOP scan behavior, operator START gating, workflow identity, archive/persistence,
and profile handling are unchanged.

## Report UI

- Previous/Next page buttons removed.
- Fixed report header remains visible.
- Fixed column-header table remains visible.
- Table body scrolls vertically with touch and uses the LVGL scrollbar.
- Fixed bottom operator buttons remain visible while the table scrolls.
- Fault rows remain ordered before OK rows.

Finite test columns:

`# | SOURCE | EXPECTED | MEASURED | R (mOhm) | R STATE | RESULT`

Cable Learn columns:

`# | SIDE A | SIDE B | NET TYPE | R (mOhm) | R STATE | STATE`

## Resistance truth rule

`Measurement` and `PhysicalScanObservation` now carry optional:

- `resistanceValid`
- `resistanceMilliOhm`
- `resistanceLimitMilliOhm`

The report prints a numeric resistance only for an electrically meaningful row
(OK/HIGH-R) with a valid resistance measurement. OPEN/SHORT/WRONG or unavailable
Kelvin data are shown as `- / N/A`; no resistance value is fabricated.

The DemoScanSource supplies deterministic resistance values only for demo/testing.
A real hardware ScanSource must populate these fields from the Kelvin/ADS122C04
measurement path. Multi-branch/common nets remain N/A until branch-selective Kelvin
sampling exists.

## Host verification

- Scan/report regression groups: 27 PASS
- Completion report contract: 22/22 PASS
- Extra23 persistence/report: 33/33 PASS
- Extra24 production identity: 17/17 PASS
- Main-menu language touch regression: PASS
- Extra19–Extra24 tail regression suite: PASS

PlatformIO is not installed in the packaging environment; validate once more with
`Clean` then `Build` on the real JC1060 PlatformIO workstation.
