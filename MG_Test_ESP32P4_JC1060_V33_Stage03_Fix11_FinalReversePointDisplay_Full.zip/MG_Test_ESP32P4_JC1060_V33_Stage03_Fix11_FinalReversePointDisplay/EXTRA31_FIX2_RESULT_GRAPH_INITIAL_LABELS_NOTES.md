# MG Smart Tester — EXTRA31 Fix2
## Result Graph Initial Pin-Label Refresh

### Field symptom
On the first entry to **GRAFİKLE GÖSTER / COMBINED**, the wiring lines were correct but the pin-number labels were incomplete (typically only pin `1` was visible). Switching to EXPECTED or MEASURED and then back to COMBINED caused all pin numbers to appear.

### Root cause
`MapGraphScreen::build()` called `lv_scr_load(screen_)` before the screen object tree was fully populated. The A/B pin labels were created afterwards with empty text, and `refresh()` filled their text/positions only after the screen was already active. On the real JC1060/LVGL render timing, the first frame could therefore be drawn from a partially prepared label tree. Pressing a view button caused a second `refresh()` and made all labels visible.

### Fix
- `build()` no longer loads the graph screen while it is being constructed.
- `begin()`, `beginResults()` and `activate()` now prepare the screen in this order:
  1. build complete object tree
  2. refresh all pin text/colors/positions
  3. resolve LVGL layout
  4. load the screen
  5. invalidate the complete screen for the first frame
- New `presentPreparedScreen()` centralizes that rule.
- This applies to both editor/learned-map graphs and result graphs, without changing the graph geometry, colors, filters, result modes, or >30-pin filter rule.

### Regression lock
`host_tests/result_graph_extra31_contract_test.py` now verifies that:
- `build()` cannot call `lv_scr_load(screen_)`;
- initial refresh happens before presentation;
- layout is resolved before screen load;
- the complete screen is invalidated after load.

### Verification
- Full existing host regression suite: PASS.
- Result-graph/live-scan contract: **25/25 PASS**.
- Direct-upload reliability: **20/20 PASS**.
- Targeted libsodium repair: **9/9 PASS**.
- `MapGraphScreen.cpp` host C++17 syntax check with LVGL stubs: PASS.

### Device build
A real ESP32-P4 PlatformIO target build was not run in the assistant environment. Build on the JC1060 project PC, then use `UPLOAD_EXISTING_FIRMWARE.bat` from EXTRA31 Fix1 for direct upload.
