# Extra25 Fix3 — Report Row Colors

Completion report rows now reuse the exact ScanScreen status palette:

- OK: `0x35D273` green
- OPEN: `0xE9EEF2` white
- SHORT: `0xFFD34D` yellow
- WRONG: `0xF04444` red
- HIGH-R: `0xFF922E` orange

The complete row is colored through LVGL `LV_EVENT_DRAW_PART_BEGIN`. Text contrast is dark on green/white/yellow/orange and white on red/untested. Cable Learn rows remain neutral because they are learned topology, not pass/fail measurements. Scrolling, fixed headers, resistance columns, NON-STOP behavior, persistence and operator actions are unchanged.
