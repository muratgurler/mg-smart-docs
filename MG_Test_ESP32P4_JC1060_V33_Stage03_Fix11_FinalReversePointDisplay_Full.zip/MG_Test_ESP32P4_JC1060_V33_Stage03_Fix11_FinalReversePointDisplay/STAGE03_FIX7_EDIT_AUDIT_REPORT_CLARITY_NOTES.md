# Stage03 Fix7 - Operator Edit Audit + Report Clarity

## Operator-edited map safety / traceability
- The original phone-supplied map is preserved separately.
- A valid local map edit is allowed, but it no longer flows silently into test preparation.
- After an actual electrical change, the received-profile screen shows a compact `old -> new` mapping summary.
- The first final-button press becomes **DEĞİŞİKLİĞİ ONAYLA**. Only after that explicit confirmation does the button return to **TESTE HAZIRLA**.
- **ORİJİNALE DÖN** restores the phone-supplied map and removes the edited-map state.
- If the operator opens the editor but ends with an electrically identical map, no extra confirmation is required.

## Mobile profile metadata into reports
- `PR`, real customer/reference, real revision (when supplied), and actual mobile profile id are preserved in `TestWorkflowController`.
- Generic placeholders `MOBILE-IMPORT` and `UNSPECIFIED` are intentionally not presented as real customer/revision values.
- Edited mobile profiles are marked with internal source code `MOBILE-BLE-EDITED` for traceability.

## Simulation clarity
- Test reports append `DEMO/SIM` for demo ScanSource runs.
- Resistance column becomes `R (mOhm) [SIM]`.
- The report explicitly says simulation results are not physical measurements.

Physical GPIO/backbone remains disabled.
