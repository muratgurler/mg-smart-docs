# Extra28 Localization Batch14 — Operator Core

## Amaç
JC1060 arayüzündeki 7 dil altyapısını yeni ekranlara genişletmek. Desteklenen diller:
Türkçe, English, Nederlands, Deutsch, Français, Español, Polski.

## Bu pakette 7 dile çıkarılan çekirdek ekranlar
- Main Menu / yeni menü kartları
- Cable Analysis / Advanced Analysis
- Completion Report (Normal/Sub-D/custom/learn rapor kabuğu)
- Analysis Report
- Settings içindeki yeni kartlar
- Extra Features
- Wi-Fi / Ethernet Network Status
- Workflow Overview
- Workflow Archive
- Workplace Server Settings

## Mimari değişiklik
`P4Localization` içine allocation yapmayan `p4SelectText(TR, EN, NL, DE, FR, ES, PL)` seçicisi eklendi.
Yeni ekran metinleri artık yalnız TR/EN ternary fallback kullanmıyor. Aktif P4Language değeri doğrudan yedi metinden birini seçiyor.

## Korunan regresyonlar
Ana menü dil seçici davranışı değiştirilmedi:
- compact yükseklik: 72 px
- extended click area: 8 px
- PRESS_LOCK
- child label/row click davranışı mevcut korumayı sürdürür

## Doğrulama
- `localization_test.cpp`: 7 dil tablosu + p4SelectText PASS
- `localization_batch14_contract_test.py`: 10 çekirdek ekran + selector + touch guard PASS
- `main_menu_language_touch_contract_test.py`: PASS
- AdvancedAnalysis, ExtraFeatures, MainMenu, Settings, CompletionReport, AnalysisReport,
  WorkflowOverview, WorkflowArchive ve WorkplaceServerSettings host syntax (`-Wall -Wextra -Werror`) PASS
- Completion Report 29/29 PASS
- Analysis Report 36/36 PASS
- Unified Result Table 21/21 PASS
- Workplace Server Config 25/25 PASS
- Function UX Batch2 PASS

## Bilerek bu pakette tamamlanmayan metinler
Aşağıdaki derin ekranlar hâlâ eski TR/EN fallback içeriyor ve sonraki localization batch'te ele alınacak:
- DocumentImportScreen
- DocumentReviewScreen
- DocumentAnalysisScreen
- DocumentNetReviewScreen
- BackboneDemoScreen içindeki servis/demo bağlam mesajları

Bu nedenle Extra28 Batch14, cihazdaki bütün metinlerin yüzde 100 çevirisi olarak değerlendirilmemelidir; operatör çekirdek katmanının 7-dil standardizasyonudur.
