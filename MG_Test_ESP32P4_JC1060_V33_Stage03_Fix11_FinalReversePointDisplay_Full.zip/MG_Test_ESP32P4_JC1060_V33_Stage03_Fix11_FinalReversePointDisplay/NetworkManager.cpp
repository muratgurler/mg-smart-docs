// Fix32 compatibility stub.
// The MG Smart Test network implementation moved to MgNetworkManager.cpp
// to avoid confusion with Arduino-ESP32's own NetworkManager class/source.
