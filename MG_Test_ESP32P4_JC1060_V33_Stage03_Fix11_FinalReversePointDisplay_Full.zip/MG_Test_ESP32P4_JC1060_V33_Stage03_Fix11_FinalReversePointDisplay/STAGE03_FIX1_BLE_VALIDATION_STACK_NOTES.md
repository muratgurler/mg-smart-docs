# Stage03 Fix1 — BLE final validation loopTask stack protection

Real JC1060 test reached BLE GATT, accepted all chunks, verified transfer CRC and durably committed `/mgdocs/profile_001.json`, then reset with `Stack protection fault` in `loopTask` before `PROFILE_READY`.

The panic showed the loopTask stack pointer below its lower stack bound. The BLE finalizer had large automatic objects (`ProductionProfileRecord` and `CableMap`) and then called document validation, which added a 1024-byte CRC buffer on the same call chain.

Fix1:
- moves `ProductionProfileRecord`, `CableProfile` and `CableMap` validation scratch objects to heap with `nothrow` allocation and fail-closed handling;
- reduces the validator CRC automatic buffer from 1024 to 256 bytes;
- avoids creating a temporary `makeDefaultCustomCableMap()` during prepared-profile validation;
- keeps all existing CRC/electrical validation and `PROFILE_READY` gates unchanged;
- logs `[BLE-PROFILE] validation scratch=HEAP ...` before independent validation.

Expected real-device terminal sequence after this fix:

`committed ...` -> `validation scratch=HEAP ...` -> `VALIDATED` notification -> `PROFILE_READY ...`
