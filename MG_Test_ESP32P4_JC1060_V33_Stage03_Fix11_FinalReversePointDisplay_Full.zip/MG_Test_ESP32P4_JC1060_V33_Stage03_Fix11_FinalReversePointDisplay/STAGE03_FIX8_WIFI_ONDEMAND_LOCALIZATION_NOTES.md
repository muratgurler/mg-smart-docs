# Stage03 Fix8 — Wi-Fi On-Demand + 7-Language Transfer UI

Date: 2026-09-19

## Operator workflow

- BLE remains the normal/primary phone-profile transport.
- Entering **TELEFONDAN PROFİL AKTAR / PHONE PROFILE IMPORT** no longer starts the temporary Wi-Fi AP automatically.
- The Wi-Fi fallback starts only when the operator explicitly presses the localized **Open Wi-Fi fallback** button.
- While Wi-Fi fallback is off, the QR code and SSID/password/address/session details are hidden.
- When Wi-Fi fallback is opened, the temporary AP is created and the QR code plus connection details are shown.
- The same button can close the temporary Wi-Fi fallback again.
- Starting a new transfer session returns to BLE-first mode with Wi-Fi fallback off.
- A completed Wi-Fi profile upload can auto-open the same operator profile summary used by BLE.

## Localization correction

The transfer screen previously had two dynamically formatted Turkish fragments that leaked into other languages:

- `Wi-Fi yedek: ...`
- `[BAĞLI]`

Both are now selected through the seven-language localization path. The Wi-Fi open/close button, fallback/QR text and fallback status are also explicitly defined for Turkish, English, Dutch, German, French, Spanish and Polish.

Permanent rule: operator-visible Turkish terminology must not appear when another UI language is active.

## Safety / architecture

- BLE `PROFILE_READY` validation behavior is unchanged.
- Wi-Fi upload still enters the same prepared-profile validation pipeline.
- Physical GPIO/backbone remains disabled and untouched.
- Existing optional map edit/revalidation and audit logic remains unchanged.

## Regression test

`host_tests/stage03_fix8_wifi_ondemand_localization_contract_test.py` verifies:

- Wi-Fi AP is not auto-started by the normal BLE-first import screen.
- Wi-Fi is explicitly operator-controlled.
- QR/credentials stay hidden until fallback is active.
- old hard-coded Turkish dynamic labels are absent.
- open/close controls have seven-language strings.
- Wi-Fi upload can still auto-open the operator summary.

The full existing host regression suite also passes.
