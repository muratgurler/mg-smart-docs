# MG Smart Tester EXTRA31 — Result Graph + Live Scan Status

Date: 2026-08-30
Base: MG30 / EXTRA30 Mobile Profile Import Core (known user-tested build)

## 1. Live scan status integration

The existing live A/B pin display and direction arrow now use the electrical result status colour instead of a generic run colour once a measurement result is available.

Status palette remains identical to the scan/report palette:
- Correct / OK: green
- Open: white
- Short: yellow
- Wrong mapping: red
- High resistance: orange
- In-progress scan: existing scanning blue

The scan screen also shows a compact live connection summary. It preserves the full sender and receiver masks, so multi-pin/common-net/short observations are not reduced to the first endpoint. Examples:
- `A12 -> B12 | OK`
- `A12 -> B15 | WRONG`
- `A15 -> OPEN | OPEN`
- `A22+A23 -> B22+B23 | SHORT`

When a valid resistance value exists, it is appended to the live summary.

## 2. Result graph

Finite test completion and Cable Learn completion reports now expose a `SHOW GRAPH / GRAFİKLE GÖSTER` action.

The existing MapGraphScreen renderer is reused rather than introducing a second graph engine.

For scan results the graph supports:
- Combined (default)
- Expected
- Measured

Combined mode draws the expected topology first in a subdued style and overlays the measured topology using the electrical status colour. Open results are represented as an open-ended status-coloured stub. Wrong mappings, shorts, high resistance and correct paths use the same palette as the result table.

One-to-one, one-to-many, many-to-one and common-net geometry are preserved by the shared branch/bus renderer. Same-side groups can also be represented.

## 3. Filter rule

Per the accepted UI rule, result-graph filters exist only when the profile has more than 30 active test points.

- `activePointCount() <= 30`: no filter row is created.
- `activePointCount() > 30`: filters become available.

Filters:
- All
- Errors
- Correct
- Open
- Short
- Wrong
- High-R

PE and dS are already part of `activePointCount()` when enabled by the profile, so the threshold follows the points actually presented by the profile.

## 4. Navigation

- Test completion -> Show Graph -> Back returns to the same completion report.
- Cable Learn completion -> Show Graph uses the learned map and returns to its completion report.
- Normal map-editor graph flow remains unchanged.

## 5. Regression protection

A new `host_tests/result_graph_extra31_contract_test.py` adds 21 contract checks covering live masks, status-colour integration, graph action wiring, result modes, the strict >30 filter threshold, result palette, actual-mask rendering, common-net rendering and return navigation.

`scan_session_test.cpp` now contains a direct behavioral regression for the live display snapshot, including wrong mapping, high-resistance value propagation and the full A22+A23 / B22+B23 short group. The scan regression suite therefore increases from 27 to 28 groups.

The existing normal-map contract was updated only for the new EXTRA31 boot identity.

## 6. Build note

No ESP32-P4 target toolchain/PlatformIO target build was available in the assistant environment. Host regression and host C++ syntax checks passed, but the actual JC1060 target build must be verified in PlatformIO on the user's machine.

For the existing working EXTRA30 installation, normal verification is **Build -> Upload**. A Clean is not required for this source-level update unless PlatformIO reports a genuine stale/generated-build problem.
