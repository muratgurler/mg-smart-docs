# Extra25 Fix4 — Natural Report Row Order

- Completion report no longer promotes faults to the top.
- Test rows remain in the same natural scan order: A->B slots in profile order, followed by B->A slots in profile order.
- OK, OPEN, SHORT, WRONG and HIGH-R only control row color/status; they do not change row position.
- Scrollable table, resistance columns, fixed header/buttons and Fix3 status colors are unchanged.
- Cable Learn report ordering is unchanged.
