# Extra27 Fix1 - GCC 14.2.0 ICE workaround

## Problem
ESP32-P4 GCC 14.2.0 could stop with an internal compiler error at:

`analysisReport_ = AnalysisReportData{};`

`AnalysisReportData` contains 128 rows x 5 cells x 64-byte cell buffers and is about 41 KiB. The aggregate assignment can make GCC materialize a large temporary while gimplifying the function.

## Fix
Both aggregate reset assignments in `BackboneDemoScreen.cpp` were replaced by `resetAnalysisReportData(analysisReport_)`.

The reset is performed in-place:
- scalar fields are restored explicitly,
- title/summary/column character buffers are cleared directly,
- each existing report row is cleared directly,
- row status is restored to `Info`,
- no large temporary `AnalysisReportData{}` object is created.

## Regression guard
`host_tests/analysis_report_batch13_contract_test.py` now fails if the unsafe aggregate assignment is reintroduced.

Targeted verification:
- Analysis report data test: PASS
- Analysis report contract: 23/23 PASS
- Extra25 completion report contract: 24/24 PASS
- Main-menu language touch regression: PASS
- Extra27 relevant C++ sources: `-Wall -Wextra -Werror -pedantic -fsyntax-only` PASS
