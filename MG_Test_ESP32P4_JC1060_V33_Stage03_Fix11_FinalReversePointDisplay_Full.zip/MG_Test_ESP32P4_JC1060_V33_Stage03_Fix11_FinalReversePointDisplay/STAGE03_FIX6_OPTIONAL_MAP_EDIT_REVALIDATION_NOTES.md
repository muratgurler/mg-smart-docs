# Stage03 Fix6 — Optional Map Edit + Revalidation

Date: 2026-09-19

## Goal

Keep the fast operator flow introduced by Fix5 while preserving the ability to inspect and, when necessary, manually correct the imported electrical map without allowing accidental edits or bypassing validation.

## Normal successful flow

1. Phone sends the already reviewed profile.
2. BLE still completes the full transport/electrical contract and reaches terminal `PROFILE_READY`.
3. The tester automatically opens **ALINAN PROFIL**.
4. Operator normally presses only **TESTE HAZIRLA**.

No extra map confirmation is required in the normal path.

## Optional map flow

The summary button is now **HARITAYI GOR / DUZENLE** (localized on-screen with Turkish characters where supported).

When opened from a phone profile:

- the map starts **locked/read-only**,
- source pins and A->B / A<->A / B<->B views can still be inspected,
- target pins cannot be changed,
- only **GERI**, **DUZENLE**, and **GRAFIKLE GOSTER** are offered.

The operator must explicitly press **DUZENLE** before any connection can be changed. This prevents an incidental touch from modifying the imported map.

After unlocking, the existing editor capabilities remain available, including one-to-one fill, clear, target editing, same-side/common-net editing and graph preview.

## Revalidation after editing

A locally edited map is not trusted automatically.

Before it is accepted:

- the edited A->B and same-side masks are copied into a heap-backed production-profile scratch record,
- `ProductionProfileContract::validate()` is run again,
- disabled points, invalid targets and same-side topology errors remain fail-closed,
- only a valid edited map replaces the previously accepted draft.

A rejected edit does not overwrite the last valid map. `TESTE HAZIRLA` remains disabled until the operator reopens the map and resolves/cancels the rejected change.

The document-profile `1:1 DOLDUR` action now fills only points enabled by the imported profile, so a 15-pin+dS profile does not accidentally create hidden 64-point connections.

## Transfer status wording

After a profile has arrived, the transfer screen no longer continues to say **Telefon baglantisi bekleniyor**. It changes to the completed-transfer state while the existing automatic move to the profile summary remains gated by terminal BLE `PROFILE_READY`.

## Preserved invariants

- Fix5 automatic transfer -> summary navigation remains unchanged.
- Normal operation still has one final operator action: **TESTE HAZIRLA**.
- BLE terminal `PROFILE_READY` remains mandatory for automatic BLE navigation.
- The original last-valid map remains intact on edit validation failure.
- Physical GPIO/backbone enablement is unchanged and remains disabled in this software stage.
- Existing graph double-buffer label fix and ASCII-safe arrows are preserved.

## Regression coverage

`host_tests/stage03_fix6_optional_map_edit_contract_test.py` adds checks for:

- completed-transfer state wording,
- terminal `PROFILE_READY` gate,
- locked-by-default document map review,
- explicit edit unlock,
- mutation blocking while locked,
- profile-limited 1:1 fill,
- heap-backed map revalidation,
- last-valid-map preservation,
- final TESTE HAZIRLA fail-closed behavior,
- return to operator summary on rejected edits,
- physical hardware layer remaining untouched.
