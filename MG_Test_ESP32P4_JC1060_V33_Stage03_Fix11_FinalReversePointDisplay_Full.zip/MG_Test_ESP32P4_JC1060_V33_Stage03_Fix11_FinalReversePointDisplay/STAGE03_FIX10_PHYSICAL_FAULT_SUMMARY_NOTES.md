# Stage03 Fix10 — Operator Physical Fault Summary

Date: 2026-09-20

## Goal

Make the finite-test completion report easier for an operator to interpret. The electrical engine scans both A->B and B->A, so a single physical defect can appear multiple times in the raw directional counters. Fix10 keeps those raw measurements intact internally and in the row table, while adding a de-duplicated operator summary for strict identity 1:1 profiles.

## Operator behavior

For a simple identity 1:1 cable, the report header now shows:

- total measurements,
- OK measurement count,
- de-duplicated physical-fault count,
- a compact localized fault summary.

The current Sub-D15 demo therefore resolves to the physical summary equivalent of:

`CROSSED 8/9 | OPEN 15`

instead of asking the operator to interpret `WRONG 4` and `OPEN 2` as four and two independent physical defects.

The wider built-in demo also collapses the bidirectional rows to one crossed pair 8/9, one open line 15, one short group 22/23 and one high-resistance line 18.

## Safety / no-guess rule

Physical de-duplication is enabled only when the expected A->B topology is a strict identity 1:1 map. One-to-many, many-to-one, splice/common-net and other complex maps deliberately retain the existing directional statistics. Fix10 therefore does not invent a physical-fault count for topologies where such a collapse would be ambiguous.

The detailed result table is unchanged and remains the source of truth for every direction-specific measurement.

## Demo clarity

The compact summary still states that DEMO values are not physical measurements, and the resistance column remains marked `[SIM]`.

## Localization

The operator fault-summary labels were added for all seven UI languages (TR/EN/NL/DE/FR/ES/PL). No Turkish-only dynamic status was introduced.

## Tests

- Host regression runner: PASS.
- `scan_session_test.cpp`: 31 regression groups PASS.
- New Fix10 contract: 12/12 PASS.
- Behavioral coverage verifies bidirectional de-duplication, Sub-D15 `8/9 + 15` summary, and fail-safe fallback for common nets.

No physical GPIO/backbone behavior was changed.
