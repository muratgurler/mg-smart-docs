# Stage03 Fix11 - Final Reverse Point Display

## Problem
In a finite two-direction scan, A->B correctly showed every point. On the automatic/manual B->A return sweep, the final B1 -> A1 measurement was taken and stored, but the UI switched to the completion report in the same main-loop iteration. As a result the operator visually saw the return sweep stop at pin 2 and then jump to the report.

## Fix
- Preserve the final B->A `displayDirection`/pin snapshot after the electrical cycle reaches `RunState::Complete`.
- Delay the completion-report screen after the final measurement.
- Final-point dwell is `max(selected scan-step interval, 300 ms)`.
  - Slow scan: final point gets the same slow dwell as other points.
  - Fast scan: final point still remains visible for at least 300 ms.
- This applies to automatic scan, normal manual single-step, and the single-step hold/jog path because all finite scans use the same completion gate.
- Report contents and electrical measurement order are unchanged. B1 -> A1 was already measured; Fix11 makes its final visual state observable before report navigation.

## Regression guards
- Host `ScanSession` test now requires the completed cycle to retain `displayDirection=BtoA`, `B1`, and `A1` in the display snapshot.
- New Fix11 source contract checks the completion hold and minimum dwell.
